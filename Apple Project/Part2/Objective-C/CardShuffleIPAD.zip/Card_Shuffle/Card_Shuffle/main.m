//
//  main.m
//  Card_Shuffle
//
//  Created by Keshav Dasu on 4/26/15.
//  Copyright (c) 2015 Keshav Dasu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
