//
//  GameScene.m
//  Card_Shuffle
//
//  Created by Keshav Dasu on 4/26/15.
//  Copyright (c) 2015 Keshav Dasu. All rights reserved.
//

#import "GameScene.h"

@implementation GameScene

@synthesize duplicate = _duplicate;
@synthesize myLabel = _myLabel;
@synthesize sq1 = _sq1;
@synthesize sq2 = _sq2;


//Creates 3 Decks (1st deck most recent shuffle) (2nd deck last shuffle) (3rd deck untouched new deck (for display))
-(void) create_deck
{
    // 0,0   ,  0.077,  0.25 = diamond row
    // 0,0.25,  0.077,  0.25 = heart row
    // 0,0.5,  0.077,  0.25 = spade row
    // 0,0.75,  0.077,  0.25 = club row
    CGFloat suit = 0.0;
    CGFloat number = 0;
    CGFloat x = 50;
    CGFloat y = 50;
    
    self.prevcards =  [[NSMutableArray alloc] init];
    self.curcards = [[NSMutableArray alloc] init];
    self.sq1 = [[myNode alloc] init];
    self.sq2 = [[myNode alloc] init];
    
    SKTexture * bi = [SKTexture textureWithImageNamed:@"classicCards"];
    SKTexture * image = [SKTexture textureWithRect:CGRectMake(number, suit, .077, 0.25) inTexture:bi];
    myNode * s1 = [myNode spriteNodeWithTexture:image];
    s1.xScale = .5;
    s1.yScale = .5;
    s1.position = CGPointMake(x,500);
    s1.physicsBody.dynamic = YES;
    self.sq1 = s1;
    [self addChild:s1];
    
    myNode * s2 = [myNode spriteNodeWithTexture:image];
    s2.xScale = .5;
    s2.yScale = .5;
    s2.position = CGPointMake(x + 25,500);
    s2.physicsBody.dynamic = YES;
    self.sq2 = s2;
    [self addChild:s2];
    
    
    SKTexture * baseImage = [SKTexture textureWithImageNamed:@"classicCards"];
    for(int i = 0; i < 52; i++)
    {
        if(i > 1 && i % 13 == 0){
            suit += .25;
            number = 0;
            y += 50;
            x = 50;
        }

        SKTexture * cardtexture = [SKTexture textureWithRect:CGRectMake(number, suit, .077, 0.25) inTexture:baseImage];
        myNode * sprite = [myNode spriteNodeWithTexture:cardtexture];
        sprite.xScale = .5;
        sprite.yScale = .5;
        sprite.position = CGPointMake(x,y);
        sprite.physicsBody.dynamic = YES;
        sprite.myID = (i + 1);
        
        [self.curcards addObject:sprite];
        [self addChild:sprite];
        
        number += .077;
        x += 25;
    }
    
    x = 675;
    y = 50;
    number = 0.0;
    suit = 0;
    for(int j = 0; j < 52; j++)
    {
        if(j > 1 && j % 13 == 0){
            suit += .25;
            number = 0;
            y += 50;
            x = 675;
        }
        
        SKTexture * cardtexture = [SKTexture textureWithRect:CGRectMake(number, suit, .077, 0.25) inTexture:baseImage];
        myNode * sprite = [myNode spriteNodeWithTexture:cardtexture];
        sprite.xScale = .5;
        sprite.yScale = .5;
        sprite.position = CGPointMake(x,y);
        sprite.physicsBody.dynamic = YES;
        sprite.myID = (j + 1);
        
        [self.prevcards addObject:sprite];
        [self addChild:sprite];
        
        number += .077;
        x += 25;
    }
    
    
    
    x = 360;
    y = 500;
    number = 0.0;
    suit = 0;
    for(int k = 0; k < 52; k++)
    {
        if(k > 1 && k % 13 == 0){
            suit += .25;
            number = 0;
            y += 50;
            x = 360;
        }
        
        SKTexture * cardtexture = [SKTexture textureWithRect:CGRectMake(number, suit, .077, 0.25) inTexture:baseImage];
        myNode * sprite = [myNode spriteNodeWithTexture:cardtexture];
        sprite.xScale = .5;
        sprite.yScale = .5;
        sprite.position = CGPointMake(x,y);
        sprite.physicsBody.dynamic = YES;
        sprite.myID = (k + 1);
        
        [self.orginalcards addObject:sprite];
        [self addChild:sprite];
        
        number += .077;
        x += 25;
    }
    
    
    
}

//Using the Fisher and Yates original method (Fisher Yates Shuffle)
-(void) shuffle:( NSMutableArray *) array{
   
    NSUInteger deck_size = 52;
    for(NSUInteger i = 0; i < deck_size;i++)
    {
        //create a random value from 0 - deck size
        int shuf = arc4random() % (deck_size - 1);
        
        myNode * card1 = [array objectAtIndex:shuf];
        myNode * card2 = [array objectAtIndex:deck_size -1];
        myNode * tempCard = [[array objectAtIndex:shuf]copy];
        int card1ID = card1.myID;
        int card2ID = card2.myID;
        
        card1.texture = card2.texture;
        card1.myID = card2ID;
        card2.texture = tempCard.texture;
        card2.myID = card1ID;
        
        [array replaceObjectAtIndex:shuf withObject:card1];
        [array replaceObjectAtIndex:deck_size - 1 withObject:card2];
        
        deck_size--;
    }
    [self printCards];
    
    // Every second compare the most recent shuffle with the last shuffle and see if they share a  sequence
    // of length 2 in common. If so set the previous shuffle to the most recent shuffle and shuffle the most recent one.
    
    [NSTimer scheduledTimerWithTimeInterval:5.0f target:self selector:@selector(reshuffle:) userInfo:nil repeats:YES];
}

// For debugging purposes this will print the most recent shuffle and the previous shuffle's UID for a card
-(void) printCards
{
    printf("Current\n\t");
    for(int i = 0; i < 52; i++)
    {
        myNode * cur = [self.curcards objectAtIndex:i];
        if(i > 1 && i % 13 == 0){
             printf("\n\t");
        }
        printf("%d, ",cur.myID);
    }
    
     printf("\nPrevious\n\t");
    for(int j = 0; j < 52; j++)
    {
        myNode * prev = [self.prevcards objectAtIndex:j];
        if(j > 1 && j % 13 == 0){
            printf("\n\t");
        }
        printf("%d, ",prev.myID);
    }
}


//Used to see if the most recent shuffle and the last shuffle have sequence of size 2 in common
-(void) duplicate_check
{
    //take previous shuffle place in a 52x2 matrix
    //for each card store the card id -> right neighbor
    int matrix[52][2];
    for(int i = 0; i + 1 < 52; i++)
    {
        myNode * prev = [self.prevcards objectAtIndex:i];
        myNode * prev_1 = [self.prevcards objectAtIndex:i + 1];
        matrix[prev.myID][0] = prev_1.myID;
    }
    
    //for the current shuffle look up for that card id in the matrix
    //and compare essentially the previous ones neighbor with the current neighbor
    //if they match then a duplicate has occurred.
    for(int j = 0; j + 1 < 52; j++)
    {
        myNode * cur = [self.curcards objectAtIndex:j];
        myNode * cur_1 = [self.curcards objectAtIndex:j + 1];
        
        if(matrix[cur.myID][0] == cur_1.myID)
        {
            //Duplicate Sequence Occurred
            self.duplicate = true;
            self.sq1.texture = cur.texture;
            self.sq2.texture = cur_1.texture;
            return;
        }
    }
    
    self.duplicate = false;
}



//will call duplicate_check  to see if there are any matching sequences
//if so then a reshuffle will occur otherwise nothing
- (void) reshuffle:(NSTimer *)timer
{
    //check if there is a duplicate
    [self duplicate_check];
    
    
    
    if(self.duplicate)
    {
        printf("\nshuffle swap\n");
        //set the right side cards to be what the leftside was
        for(int i = 0; i < 52; i++)
        {
            myNode * prev_card = [self.prevcards objectAtIndex:i];
            myNode * cur_card = [self.curcards objectAtIndex:i];
            int pmyID = cur_card.myID;
            
            prev_card.myID = pmyID;
            prev_card.texture = cur_card.texture;
            [self.prevcards replaceObjectAtIndex:i withObject:prev_card];
        }
        
        //shuffle left side
        NSMutableArray * temp = [self curcards];
        [self shuffle:temp];
        
        self.duplicate = false;
    }else{
        self.myLabel.text = @"Done";
        self.sq1.removeFromParent;
        self.sq2.removeFromParent;
    }
}

-(void)didMoveToView:(SKView *)view {
    /* Setup your scene here */
    self.duplicate = true;
    [self create_deck];
    NSMutableArray * temp = [self curcards];
    [self shuffle:temp];
    
    self.myLabel = [SKLabelNode labelNodeWithFontNamed:@"GillSans"];
    
    self.myLabel.text = @"shuffling";
    self.myLabel.fontSize = 65;
    self.myLabel.position = CGPointMake(CGRectGetMidX(self.frame),
                                   CGRectGetMidY(self.frame));
    
    [self addChild:self.myLabel];
    
    SKLabelNode *myLabel2 = [SKLabelNode labelNodeWithFontNamed:@"GillSans"];
    myLabel2.text = @"Current Shuffle";
    myLabel2.fontSize = 30;
    myLabel2.position = CGPointMake(CGRectGetMidX(self.frame) - 350,
                                   CGRectGetMidY(self.frame) - 100);
    [self addChild:myLabel2];
    
    
    SKLabelNode *myLabel3 = [SKLabelNode labelNodeWithFontNamed:@"GillSans"];
    myLabel3.text = @"Common Sequence";
    myLabel3.fontSize = 15;
    myLabel3.position = CGPointMake(CGRectGetMidX(self.frame) - 425,
                                    CGRectGetMidY(self.frame) + 150);
    [self addChild:myLabel3];
    
    
    SKLabelNode *myLabel4 = [SKLabelNode labelNodeWithFontNamed:@"GillSans"];
    myLabel4.text = @"Previous Shuffle";
    myLabel4.fontSize = 30;
    myLabel4.position = CGPointMake(CGRectGetMidX(self.frame) + 350,
                                    CGRectGetMidY(self.frame) - 100);
    [self addChild:myLabel4];
    
    
}

//Not currently beign used
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    
   /* for (UITouch *touch in touches) {
        //CGPoint location = [touch locationInNode:self];

    }*/
}

-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
   
}

@end
