//
//  GameScene.h
//  Card_Shuffle
//

//  Copyright (c) 2015 Keshav Dasu. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
#import "myNode.h"

@interface GameScene : SKScene
@property (nonatomic) NSMutableArray * prevcards;
@property (nonatomic) NSMutableArray * curcards;
@property (nonatomic) NSMutableArray * orginalcards;
@property bool duplicate;
@property SKLabelNode *myLabel;
@property myNode * sq1;
@property myNode * sq2;

@end
