//
//  myNode.m
//  Card_Shuffle
//
//  Created by Keshav Dasu on 4/26/15.
//  Copyright (c) 2015 Keshav Dasu. All rights reserved.
//

#import "myNode.h"

@implementation myNode{ }

@synthesize myID = _myID;

@end
