//
//  AppDelegate.h
//  Card_Shuffle
//
//  Created by Keshav Dasu on 4/26/15.
//  Copyright (c) 2015 Keshav Dasu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

